/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import Entites.message;
import java.util.List;
import java.sql.SQLException;


public interface serviceMessage  {
   public void AddMessage(message m) throws SQLException; 
   public List<message> affichermessage() throws SQLException;
   public void DeleteMessage(int id) throws SQLException;
   public void UpdateMessage(message m) throws SQLException;
}
