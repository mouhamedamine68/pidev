/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatapp;

import Entites.message;
import Service.serviceMessagee;
import Utils.Maconnexion;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.util.Callback;

/**
 *
 * @author dell
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private TextField tfmsg;
    @FXML
    private Label labelAffiche;
    @FXML
    private TextField idd;
    @FXML
    private TextField tfsearch;
    @FXML
    private TableView tableview;
    ObservableList<ObservableList> liste ;
  @FXML 
    private AnchorPane btnsearch;
  Connection cnx;
  TableColumn col ;
  
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    private final ObservableList<message> dataList=FXCollections.observableArrayList();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        TableView();
    }    

    @FXML
    private void ajouterMessage(ActionEvent event)throws SQLException {    
        Service.serviceMessagee sm=new serviceMessagee();
        message m=new message();
        m.setMessage_content(tfmsg.getText()); 
       

        sm.AddMessage(m);      
        TableView();
    }

    @FXML
    private void supprimerMessage(ActionEvent event)throws SQLException {
        int i;   
        serviceMessagee sm=new serviceMessagee();
                i=Integer.parseInt(idd.getText());
               
              sm.DeleteMessage(i);
              TableView();

    
    }

    @FXML
    private void modifierMessage(ActionEvent event)throws SQLException {
    int i;
                message m=new message();
    i=Integer.parseInt(idd.getText());
    m.setMessage_id(i);
    m.setMessage_content(tfmsg.getText());
            serviceMessagee sm=new serviceMessagee();

              sm.UpdateMessage(m);
              TableView();
    
    }

    @FXML
    private void afficherMessage(ActionEvent event) throws SQLException {
        serviceMessagee sm=new serviceMessagee();
        labelAffiche.setText(sm.affichermessage().toString());
    }

    
   
    private void TableView() {
        cnx=Maconnexion.getInstance().getCnx();
        tableview.getColumns().clear();
          
          liste = FXCollections.observableArrayList();
        
            String SQL = "SELECT DISTINCT u.nom,m.message_content FROM users u JOIN message m ON u.user_id=m.user_id ";//
           
           
           
        try {
             ResultSet rs = cnx.createStatement().executeQuery(SQL);
            for(int i=0 ; i<rs.getMetaData().getColumnCount(); i++){
                final int j = i;                
                col = new TableColumn(rs.getMetaData().getColumnName(i+1));
                //col.setStyle("-fx-pref-width:250px;");
                col.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ObservableList,String>,ObservableValue<String>>(){
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<ObservableList, String> param) {
                        return new SimpleStringProperty(param.getValue().get(j).toString());
                    }                    
                });
                
                
                tableview.getColumns().addAll(col); 
                System.out.println("Column ["+i+"] ");
            }
      

            
       
            while(rs.next()){
                
                ObservableList<String> row = FXCollections.observableArrayList();
                for(int i=1 ; i<=rs.getMetaData().getColumnCount(); i++){
                    
                    row.add(rs.getString(i));
                }
                System.out.println(row);
                liste.add(row);
            }
        

            
            tableview.setItems(liste);
          }catch(Exception e){
              e.printStackTrace();
              System.out.println(e);             
          }
    }
    
    
}
