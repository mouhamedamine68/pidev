/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entites.message;
import Services.serviceMessage;
import Utils.Maconnexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dell
 */
public class serviceMessagee implements serviceMessage{
    Connection cnx;
    List<message> messages=new ArrayList<>();

    public serviceMessagee(){
    cnx=Maconnexion.getInstance().getCnx()  ;
    }
    
    @Override
    public void AddMessage(message m)throws SQLException {
        try {
            Statement stm=cnx.createStatement();
       
        String query="INSERT INTO `message`(`message_content`) VALUES ('"+m.getMessage_content()+"')";
      
        stm.executeUpdate(query);
        
        } catch (SQLException ex) {
            Logger.getLogger(serviceMessagee.class.getName()).log(Level.SEVERE, null, ex);
        }   
        }

    @Override
    public List<message> affichermessage()throws SQLException {
        
            Statement stm=cnx.createStatement();
       
    String query="SELECT * FROM `message`";
            ResultSet rst=stm.executeQuery(query);
            
                  List<message> messages=new ArrayList<>();
        while(rst.next())
        {
        message m=new message();
        m.setMessage_id(rst.getInt("message_id"));
        m.setMessage_content(rst.getString("message_content"));
        
        messages.add(m);
        }
        
        
        
     
    return messages;
    }

    public void DeleteMessage(int id)throws SQLException {
  try {
            Statement stm=cnx.createStatement();
       
        String query="DELETE FROM `message` WHERE  message_id = '"+ id+"'";
      
        stm.executeUpdate(query);
        
        } catch (SQLException ex) {
            Logger.getLogger(serviceMessagee.class.getName()).log(Level.SEVERE, null, ex);
        }   

    }

    @Override
    public void UpdateMessage(message m) throws SQLException{
   
          
            Statement stm=cnx.createStatement();
       
        String query="UPDATE message SET message_content= '"+m.getMessage_content()+"'  WHERE message_id='"+m.getMessage_id()+"'";
      
        
        
        stm.executeUpdate(query);
        
       
    }
    
}
