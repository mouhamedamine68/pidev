/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entites;

/**
 *
 * @author dell
 */
public class message {
 private int message_id;
 private String message_content;

 
 
    
 
 public message(){
 
 }

    public message(int i, String bonjour) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getMessage_id() {
        return message_id;
    }

    public void setMessage_id(int message_id) {
        this.message_id = message_id;
    }

    public String getMessage_content() {
        return message_content;
    }

    public void setMessage_content(String message_content) {
        this.message_content = message_content;
    }

  

  

    @Override
    public String toString() {
        return "message{" + "message_id=" + message_id + ", message_content=" + message_content +  "}\n";
    }
 
 
}
