/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicerec;

import Entitesrec.chat_rec;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author dell
 */
public interface serviceReclamation {
   public void AddReclamation(chat_rec rec)throws SQLException; 
   public List<chat_rec> afficherrec()throws SQLException; 
      public void DeleteReclamation(int id)throws SQLException; 

         public void UpdateReclamation(chat_rec rec)throws SQLException; 

}
