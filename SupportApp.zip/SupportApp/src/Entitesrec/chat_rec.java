/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entitesrec;

/**
 *
 * @author dell
 */
public class chat_rec {
    private int chat_id;
 private String chatrec_content;

    public chat_rec() {
    }

    public chat_rec(int chat_id, String chatrec_content) {
        this.chat_id = chat_id;
        this.chatrec_content = chatrec_content;
    }
 
 

    public int getChat_id() {
        return chat_id;
    }

    public void setChat_id(int chat_id) {
        this.chat_id = chat_id;
    }

    public String getChatrec_content() {
        return chatrec_content;
    }

    public void setChatrec_content(String chatrec_content) {
        this.chatrec_content = chatrec_content;
    }

    @Override
    public String toString() {
        return "chat_rec{" + "chat_id=" + chat_id + ", chatrec_content=" + chatrec_content + "}\n";
    }

    
 
 
 
 
 
}
