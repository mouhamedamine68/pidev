/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service2rec;

import Entitesrec.chat_rec;
import Servicerec.serviceReclamation;
import Utilsrec.Maconnexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dell
 */
public class serviceReclamationn implements serviceReclamation {
Connection cnx;
    List<chat_rec> reclamations=new ArrayList<>();
    public serviceReclamationn() {
    
       cnx = Maconnexion.getInstance().getCnx();
    }

    
    @Override
    public void AddReclamation(chat_rec rec)throws SQLException {

        
          try{
            Statement stm=cnx.createStatement();
       
          String query= "INSERT INTO `chat_rec`(`chatrec_content`) VALUES ('"+rec.getChatrec_content()+"')";

          stm.executeUpdate(query);
          
           } catch (SQLException ex) {
            Logger.getLogger(serviceReclamationn.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
    
        
        
    }

    @Override
    public List<chat_rec> afficherrec() throws SQLException{

            Statement stm=cnx.createStatement();
       
    String query="SELECT * FROM `chat_rec`";
            ResultSet rst=stm.executeQuery(query);
            
                    List<chat_rec> chats=new ArrayList<>();
        while(rst.next())
        {
        chat_rec rec=new chat_rec();
        rec.setChat_id(rst.getInt("chat_id"));
        rec.setChatrec_content(rst.getString("chatrec_content"));

        
        
       chats.add(rec);
        }
        
        
        
        
      
    return chats;
    } 

    public void DeleteReclamation(int id)throws SQLException {
    
            Statement stm=cnx.createStatement();
       
        
                String query="DELETE FROM `chat_rec` WHERE  chat_id = '"+ id+"'";

      
        stm.executeUpdate(query);
        
       
    }

    @Override
    public void UpdateReclamation(chat_rec rec)throws SQLException {

         
            Statement stm=cnx.createStatement();
       
      
        String query="UPDATE chat_rec SET chatrec_content= '"+rec.getChatrec_content()+"'  WHERE chat_id='"+rec.getChat_id()+"'";

        stm.executeUpdate(query);
       
        
    }

    
}
    

