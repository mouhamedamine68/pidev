/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package supportapp;

import Entitesrec.chat_rec;
import Service2rec.serviceReclamationn;
import Utilsrec.Maconnexion;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author dell
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private TextField tfrec;
    @FXML
    private Label labelrec;
@FXML    
        private TextField iddd;
@FXML    
        private TextField search;
@FXML
    private TableView<chat_rec> tableview;
        @FXML
    private TableColumn<chat_rec, Integer> id;
        @FXML
    private TableColumn<chat_rec, String> reclamation;
        ObservableList<chat_rec> data = FXCollections.observableArrayList();
        Connection cnx;

    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
UpdateTable();   
    search();
    }    

    @FXML
    private void ajouterrec(ActionEvent event) throws SQLException {
        
        Service2rec.serviceReclamationn sr=new serviceReclamationn();
        chat_rec cr=new chat_rec();
        cr.setChatrec_content(tfrec.getText());
        
        
        sr.AddReclamation(cr); 
        UpdateTable();
        search();
    
        
    
    }

    @FXML
    private void supprimerrec(ActionEvent event) throws SQLException{
        int i;
        i=Integer.parseInt(iddd.getText());
        serviceReclamationn sm=new serviceReclamationn();
                
              sm.DeleteReclamation(i);
              UpdateTable();
              search();
    }

    @FXML
    private void modifierrec(ActionEvent event) throws SQLException{
        int i;
        chat_rec cr=new chat_rec();
            i=Integer.parseInt(iddd.getText());
            cr.setChat_id(i);
            cr.setChatrec_content(tfrec.getText());
         serviceReclamationn sr=new serviceReclamationn();
                
               
              sr.UpdateReclamation(cr);
              UpdateTable();
              search();
              
            
    }

    @FXML
    private void afficherrec(ActionEvent event) throws SQLException{
      serviceReclamationn sr=new serviceReclamationn();
        labelrec.setText(sr.afficherrec().toString());
    
    }
    public void UpdateTable(){
        
        data.clear();
        try {
             cnx=Maconnexion.getInstance().getCnx();
            String requete = "SELECT * FROM chat_rec ";
            PreparedStatement pst = cnx.prepareStatement(requete);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                data.add(new chat_rec(rs.getInt("chat_id"), rs.getString("chatrec_content")));
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
       
        id.setCellValueFactory(new PropertyValueFactory<chat_rec, Integer>("chat_id"));
        reclamation.setCellValueFactory(new PropertyValueFactory<chat_rec, String>("chatrec_content"));
       
        tableview.setItems(data);
    }
    
    void search(){ 
     
     
        id.setCellValueFactory(new PropertyValueFactory<>("chat_id"));
        reclamation.setCellValueFactory(new PropertyValueFactory<>("chatrec_content"));
        
        tableview.setItems(data);
             FilteredList<chat_rec> filteredData = new FilteredList<>(data, b -> true);
        search.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(U -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();

                
                if (U.getChatrec_content().toLowerCase().contains(lowerCaseFilter)) {
                    return true;
                } 
              
                else {
                    return false; // Does not match.
                }
            });
        });
        SortedList<chat_rec> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(tableview.comparatorProperty());
        tableview.setItems(sortedData);    
    }
    
}
